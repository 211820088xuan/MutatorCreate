#!/bin/bash
# 24 小时 fuzz 实验：2 臂（default / custom）× 5 次重复，共 10 个并行 run
#
# 用法（容器内）:
#   bash /exp/fuzz_exp2/pipeline/run_all.sh [小时数] [自定义占比]
#   默认: 24 小时, custom 臂 LIBREDWG_CUSTOM_PCT=40
#
# 特性:
#   · 可续跑：已完成的 run 有 .done 标记，重跑脚本会跳过
#   · 磁盘看门狗：可用空间低于 MIN_FREE_GB 时停止所有 run 并留下 .disk_low
#   · 崩溃不停止：-ignore_crashes=1 -ignore_ooms=1 -ignore_timeouts=1
set -u

EXP=/exp
OUT=$EXP/fuzz_exp2
BIN=$OUT/llvmfuzz
SEEDS=$EXP/seeds
PIPE=$OUT/pipeline

HOURS=${1:-24}
PCT=${2:-40}
SECS=$((HOURS * 3600))
REPS=5
MIN_FREE_GB=${MIN_FREE_GB:-3}

mkdir -p "$OUT"
[ -x "$BIN" ] || { echo "缺少可执行文件 $BIN"; exit 1; }
[ -d "$SEEDS" ] || { echo "缺少种子目录 $SEEDS"; exit 1; }

echo "=== 配置 ==="
echo "  时长    : ${HOURS}h (${SECS}s)"
echo "  重复    : ${REPS} 次/臂"
echo "  custom  : LIBREDWG_CUSTOM_PCT=${PCT}"
echo "  种子    : $(ls "$SEEDS"/*.dxf 2>/dev/null | wc -l) 个 .dxf"
echo "  磁盘    : $(df -h / | tail -1 | awk '{print $4}') 可用（低于 ${MIN_FREE_GB}G 会停止）"
echo "  失败阈值: rss_limit=2560MB/run"
echo ""

pids=()
names=()

launch() {
  local arm=$1 rep=$2
  local d="$OUT/${arm}_${rep}"
  if [ -f "$d/.done" ]; then
    echo "  [skip] ${arm}_${rep} 已完成"
    return
  fi
  rm -rf "$d"
  mkdir -p "$d/corpus" "$d/crash"
  cp "$SEEDS"/*.dxf "$d/corpus/" 2>/dev/null

  local off pct
  if [ "$arm" = "default" ]; then off=1; pct=""; else off=0; pct=$PCT; fi

  echo "  [start $(date '+%T')] ${arm}_${rep}  OFF=$off PCT=${pct:-n/a}"
  if [ "$arm" = "default" ]; then
    LIBREDWG_MUTATOR_OFF=$off \
    ASAN_OPTIONS=detect_leaks=0 LSAN_OPTIONS=detect_leaks=0 \
      "$BIN" -max_total_time="$SECS" -fork=1 -seed=1 \
        -timeout=25 -rss_limit_mb=2560 \
        -ignore_crashes=1 -ignore_ooms=1 -ignore_timeouts=1 \
        -print_final_stats=1 -artifact_prefix="$d/crash/" \
        "$d/corpus" > "$d/run.log" 2>&1 &
  else
    LIBREDWG_MUTATOR_OFF=$off LIBREDWG_CUSTOM_PCT=$pct \
    ASAN_OPTIONS=detect_leaks=0 LSAN_OPTIONS=detect_leaks=0 \
      "$BIN" -max_total_time="$SECS" -fork=1 -seed=1 \
        -timeout=25 -rss_limit_mb=2560 \
        -ignore_crashes=1 -ignore_ooms=1 -ignore_timeouts=1 \
        -print_final_stats=1 -artifact_prefix="$d/crash/" \
        "$d/corpus" > "$d/run.log" 2>&1 &
  fi
  pids+=($!)
  names+=("${arm}_${rep}")
  echo "$!" > "$d/.pid"
}

echo "=== 启动 10 个 run ==="
for arm in default custom; do
  for rep in 1 2 3 4 5; do
    launch "$arm" "$rep"
  done
done

if [ ${#pids[@]} -eq 0 ]; then
  echo "全部已完成，无需启动"
  touch "$OUT/.fuzz_done"
  exit 0
fi

echo ""
echo "已启动 ${#pids[@]} 个进程: ${names[*]}"
echo ""

# ---------- 磁盘看门狗 ----------
(
  while :; do
    alive=0
    for p in "${pids[@]}"; do kill -0 "$p" 2>/dev/null && alive=1; done
    [ "$alive" -eq 0 ] && break
    free=$(df -BG --output=avail / | tail -1 | tr -dc '0-9')
    if [ "${free:-0}" -lt "$MIN_FREE_GB" ]; then
      echo "[watchdog $(date '+%T')] 磁盘仅剩 ${free}G，停止所有 run"
      touch "$OUT/.disk_low"
      for p in "${pids[@]}"; do kill -TERM "$p" 2>/dev/null; done
      break
    fi
    sleep 120
  done
) &
WD=$!

wait
kill "$WD" 2>/dev/null

# ---------- 标记完成 ----------
ok=0
for i in "${!pids[@]}"; do
  n=${names[$i]}
  if grep -q "exiting:" "$OUT/$n/run.log" 2>/dev/null; then
    touch "$OUT/$n/.done"
    ok=$((ok + 1))
  fi
done
touch "$OUT/.fuzz_done"

echo ""
echo "=== fuzz 阶段结束 $(date '+%T') ==="
echo "  正常结束: $ok / ${#pids[@]}"
[ -f "$OUT/.disk_low" ] && echo "  ⚠ 因磁盘不足被中断（见 $OUT/.disk_low）"
echo ""

# ---------- 重放 + 汇总 ----------
echo "=== 重放（oneshot）==="
python3 "$PIPE/../replay.py" --root "$OUT" --mode oneshot 2>&1 | tail -5 || true

echo ""
echo "=== 汇总 ==="
python3 "$PIPE/../summarize.py" "$OUT" --replay none 2>&1 | tail -25 || true

echo ""
echo "=== 全部完成 $(date '+%T') ==="
